package com.wdjr.springboot.bean;

import org.springframework.data.jpa.repository.JpaRepository;


public interface NodeRepository extends JpaRepository<DBNode, Long> {

}