package com.wdjr.springboot.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice //controller的增强
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class) //给controller添加异常处理，括号中指定要捕获处理哪种异常，Exception.class表示处理所有种类的异常
    @ResponseBody  //返回给浏览器显示出来
    public Map<String,String> handler1(Exception e){ //如果要使用异常对象，可以作为参数传入异常对象
        Map<String, String> map = new HashMap<>(2);
        map.put("errorCode", "01");
        map.put("errorMsg", "系统发生错误！"+e.getMessage());  //可以传回自定义的信息，也可以传回e.getMessage()
        return map;
    }

    /**
     * 拦截捕捉自定义异常 MyException.class
     * @param myex
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = MyException.class)
    public Map<String,Object> myExceptionHandler(MyException myex){
        Map<String,Object> map  = new HashMap<String,Object>();
        map.put("code",myex.getCode());
        map.put("message",myex.getMessage());
        map.put("method",myex.getMethod());
        map.put("descinfo",myex.getDescinfo());
        //发生异常进行日志记录，写入数据库或者其他处理，此处省略
        return map;
    }


}