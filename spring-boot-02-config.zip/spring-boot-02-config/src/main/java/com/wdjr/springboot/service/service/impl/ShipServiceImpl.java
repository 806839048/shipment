package com.wdjr.springboot.service.service.impl;

import com.wdjr.springboot.bean.DBNode;
import com.wdjr.springboot.bean.Node;
import com.wdjr.springboot.bean.NodeRepository;
import com.wdjr.springboot.exception.MyException;
import com.wdjr.springboot.service.ShipService;
import com.wdjr.springboot.util.TreeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by yuhui on 2020/6/25.
 */

@Service
public class ShipServiceImpl implements ShipService {

    @Autowired
    private NodeRepository repository;

    private Logger logger= LoggerFactory.getLogger(ShipServiceImpl.class);

    /**
     * 拆分货物
     * @param root
     * @param N  拆分比例
     */
    @Override
    public void split(DBNode root, String N) {
        //先保存根几点
        repository.saveAndFlush(root);
        String[] splits=  N.split(":");
        int splitSize =0;
        if(null!=splits && splits.length>0){
            splitSize=splits.length;
        }
        try{
        List<String> splitlis = Arrays.asList(splits);
            //获取分配总份数
        int sumNum=splitlis.stream().mapToInt(x -> {
            return  Integer.parseInt(x);
        }).sum();
            //子节点id以根节点id向后加
        int star=Integer.parseInt( root.getId()+"");
            //根据分配分数创建子节点
        for(int i=star;i<splitSize+star;i++){
            DBNode child = new DBNode();
            Integer num=Integer.parseInt(splits[i-star]) ;
            int tid= i+1;
            child.setId(Long.parseLong(tid+""));
            child.setName("ship" + tid);
            child.setData(root.getData().multiply(new BigDecimal(num)).divide(new BigDecimal(sumNum)) );
            child.setPid(root.getId());
            //子节点保存到h2
            repository.saveAndFlush(child);
            logger.info("=====子节点保存到h2==");
            //子节点保存到内存树结构，可以省略
            TreeUtils.insert(root,root.getId(),child);
            logger.info("=====子节点保存到内存树结构，可以省略==");
        }
        }catch (Exception e){
            throw new MyException("1001","splitOp","split","拆分货物异常！");
        }


    }

    /**
     * 合并节点
     * @param name---需要合并的节点
     * @return
     */
    @Override
    public DBNode merge( List<String> name) {


        BigDecimal mergeNum=new BigDecimal("0");
        StringBuilder id=new StringBuilder();
        StringBuilder mergename=new StringBuilder();
        DBNode root=null;
        List<DBNode> sonNode = new ArrayList<>();
        try{
            //遍历需要合并的节点名
        for(int i=0;i<name.size();i++){

            DBNode dbNode= new DBNode();
            dbNode.setName(name.get(i));
            ExampleMatcher matcher = ExampleMatcher.matching() //构建对象
                    .withMatcher("name", ExampleMatcher.GenericPropertyMatchers.contains()); //姓名采用“开始匹配”的方式查询
            Example<DBNode> ex = Example.of(dbNode,matcher);

            //根据节点名获取节点，一个名字一个节点
            List<DBNode> one= repository.findAll(ex);

            //获取此节点根信息
            if(root==null){
                Optional<DBNode>   rootOne=repository.findById(one.get(0).getPid());
                root=rootOne.get();
            }
            //删除需要合并的节点，并记录合并数据
            if(null!=one){
                mergeNum=mergeNum.add(one.get(0).getData());
                id.append(one.get(0).getId());
                mergename.append(one.get(0).getName());
                TreeUtils.deleteByName(root, name.get(i));
                repository.delete(one.get(0));
            }
        }
        }catch (Exception e){
            throw new MyException("1002","mergedelet","merge","删除需合并货物异常！");
        }

        try{
            //获取剩下的不需合并的节点
        DBNode chNode= new DBNode();
        chNode.setPid(root.getId());
        ExampleMatcher matcher = ExampleMatcher.matching() //构建对象
                .withMatcher("pid", ExampleMatcher.GenericPropertyMatchers.contains()); //姓名采用“开始匹配”的方式查询
        Example<DBNode> ex = Example.of(chNode,matcher);
        List<DBNode> chOnes= repository.findAll(ex);
        if (null!=chOnes){
            chOnes.stream().forEach(x->{
                sonNode.add(x);
            });
        }
       //创建新的合并节点
        DBNode child = new DBNode();
        child.setId(Long.parseLong(id.toString()) );
        child.setName(mergename.toString());
        child.setData(mergeNum);
        child.setPid(root.getId());
            //构造根节点的子节点
        root.setSonList(sonNode);
            //保存新节点到数据库
        repository.saveAndFlush(child);
            logger.info("=====保存新节点到数据库==");
            //保存新节点到内存，可以省略
        TreeUtils.insert(root,1L,child);
            logger.info("=====保存新节点到内存，可以省略==");
            return child;
        }catch (Exception e){
            throw new MyException("1003","mergeOperate","merge","合并货物异常！");
        }
    }

    @Override
    public void updateQuantity(Integer num) {
        DBNode root= new DBNode();
        root.setName("root");
        ExampleMatcher matcher = ExampleMatcher.matching() //构建对象
                .withMatcher("name", ExampleMatcher.GenericPropertyMatchers.contains()); //姓名采用“开始匹配”的方式查询
        Example<DBNode> ex = Example.of(root,matcher);
        //根据根节点的默认名字，查询根节点的信息
        List<DBNode> ones= repository.findAll(ex);
        if (null!=ones){
            root=ones.get(0);
        }
        BigDecimal orgNum = new BigDecimal(root.getData()+"");
        BigDecimal newNum = new BigDecimal(num+"");
        //计算出缩放比例
        BigDecimal ration= newNum.divide(orgNum);

        root.setData(newNum);
        //更新根节点的缩放后的数据
        TreeUtils.updateData(root,root.getId()+"",newNum);
        repository.saveAndFlush(root);

        //查询根节点下的子节点
        DBNode chNode= new DBNode();
        chNode.setPid(root.getId());
        ExampleMatcher matcherSon = ExampleMatcher.matching() //构建对象
                .withMatcher("pid", ExampleMatcher.GenericPropertyMatchers.contains()); //姓名采用“开始匹配”的方式查询
        Example<DBNode> exSon = Example.of(chNode,matcherSon);
        List<DBNode> chOnes= repository.findAll(exSon);
        List<DBNode> sonList= chOnes;
        root.setSonList(sonList);
        //按比例更新所有子节点数据
        logger.info("=====按比例更新所有子节点数据==");
        if (null!=sonList){
            for(int i=0;i<sonList.size();i++){
                DBNode sunData = sonList.get(i);
                sunData.setData(sunData.getData().multiply(ration));
                TreeUtils.updateData(root, sunData.getId() + "", sunData.getData().multiply(ration));
                repository.saveAndFlush(sunData);
            }

        }
    }
}
