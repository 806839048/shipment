package com.wdjr.springboot.bo;

/**
 * @title 消息响应实体类
 * @author yuhui
 * @date 2020年6月27日
 */
public class ResponseMsg extends Response {

	private String msg;

	public String getMsg() {
        return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
