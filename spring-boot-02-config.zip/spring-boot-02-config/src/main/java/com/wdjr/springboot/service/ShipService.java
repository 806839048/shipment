package com.wdjr.springboot.service;

import com.wdjr.springboot.bean.DBNode;
import com.wdjr.springboot.bean.Node;

import java.util.List;

public interface ShipService {

    public void split(DBNode root,String N);

    public DBNode merge(List<String> name);

    public void updateQuantity(Integer num);

}
