package com.wdjr.springboot.controller;

import com.wdjr.springboot.bean.DBNode;
import com.wdjr.springboot.bean.NodeRepository;
import com.wdjr.springboot.bo.ResponseMsg;
import com.wdjr.springboot.service.ShipService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class ShipController {


    @Autowired
    ShipService shipServiceImpl;

    @Autowired
    private NodeRepository repository;

   private Logger logger= LoggerFactory.getLogger(ShipController.class);



    /*
    *调用说明：http://localhost/shipSplit/100/2:3:5
     */
    @RequestMapping("/shipSplit/{quantity}/{splitNum}")
    public  ResponseMsg shipSplit(@PathVariable Integer quantity,@PathVariable String splitNum ){
        List<DBNode> dbNodes = repository.findAll();
        //创建根节点
        DBNode root = new DBNode();
        root.setData( new BigDecimal(quantity+"") );
        root.setName("root");
        root.setId(1L);
        List<DBNode> sonList = new ArrayList<>();
        root.setSonList(sonList);
        logger.info("======分配插入===");
        shipServiceImpl.split(root, splitNum);
        ResponseMsg res = new ResponseMsg();
        res.setCode("200");
        res.setMsg(splitNum+"==拆分完成==");
        return res;
    }

    /*
    *调用说明：http://localhost/shipMeger/100/ship2,ship3
     */
    @RequestMapping("/shipMeger/{quantity}/{names}")
    public  ResponseMsg shipMeger(@PathVariable Integer quantity,@PathVariable String names ){
        //合并
        String[] splitNames=  names.split(",");
        List<String> splitlis = Arrays.asList(splitNames);
        logger.info("======合并===");
        DBNode mergeNode = shipServiceImpl.merge(splitlis);
        ResponseMsg res = new ResponseMsg();
        res.setCode("200");
        res.setMsg(names+"==合并完成==");
        return res;
    }

    /*
  *调用说明：http://localhost/shipRation/10
   */
    @RequestMapping("/shipRation/{quantity}")
    public  ResponseMsg shipRation(@PathVariable Integer quantity ){

        logger.info("======缩放===");
        shipServiceImpl.updateQuantity(quantity);
        ResponseMsg res = new ResponseMsg();
        res.setCode("200");
        res.setMsg(quantity + "==缩放完成==");
        return res;
    }

}
