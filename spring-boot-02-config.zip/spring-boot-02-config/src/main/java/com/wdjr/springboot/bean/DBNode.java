package com.wdjr.springboot.bean;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "T_NODE")
public class DBNode {
    @Id
    @Column(name = "node_id")
    private Long  id;          //结点id

    @Column(name = "node_name")
    private String name;        //结点名称

    @Column(name = "node_data")
    private BigDecimal data;        //数值

    @Column(name = "node_pid")  //父id
    private Long pid;

    @Transient
    private List<DBNode> sonList; //该结点的 子结点集合

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getData() {
        return data;
    }

    public void setData(BigDecimal data) {
        this.data = data;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public List<DBNode> getSonList() {
        return sonList;
    }

    public void setSonList(List<DBNode> sonList) {
        this.sonList = sonList;
    }


}
