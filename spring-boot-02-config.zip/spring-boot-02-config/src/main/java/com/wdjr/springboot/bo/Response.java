package com.wdjr.springboot.bo;

/**
 - @title 响应实体父类
 - @author yuhui
 - @date 2020年6月27日
 */
public class Response {

    private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
