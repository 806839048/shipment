package com.wdjr.springboot.util;

/**
 * 不遍历数组求和
 * 方法省略异常检查
 */
public class SumUtil {

    public static void main(String[] args) {
        int[] arr = {5,1,8,3,7,2,6};
        System.out.println(sum(arr, arr.length));
        System.out.println(sum2(arr));
    }
    
    /**
     * 方式一：递归，传数组长度
     * @param arr
     * @param n
     * @return
     */
    private static int sum(int arr[], int n) {
        if(n == 1) {
            return arr[0];
        }else {
            return arr[n-1] + sum(arr, --n);
        }
    }
    
    /**
     * 方式二：递归，不传数组长度
     * @param arr
     * @return
     */
    private static int sum2(int arr[]) {
        int len = arr.length;
        if(len == 1) {
            return arr[0];
        }else {
            arr[len - 2] += arr[len - 1];
            int[] tempArr = new int[len - 1];
            System.arraycopy(arr, 0, tempArr, 0, len - 1);
            return sum2(tempArr);
        }
    }
}