package com.wdjr.springboot.bean;

import java.util.List;


public class Node {
    private String id;          //结点id
    private String name;        //结点名称
    private Integer data;        //数值
    private List<Node> sonList; //该结点的 子结点集合

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Node> getSonList() {
        return sonList;
    }

    public Integer getData() {
        return data;
    }

    public void setData(Integer data) {
        this.data = data;
    }

    public void setSonList(List<Node> sonList) {
        this.sonList = sonList;
    }
}
